let  Information = {
    id:"vn001",
    name:"Huỳnh Vĩ Khang",
    phone:"0809416xxxx",
    address:"jav",
    info :function(){
        return " Hãy nhập vào đây: " +this.Information
    }

}
delete Information.address;
Information.Email="khang@gmail.com"
console.log("Đây là thông tin của bạn: ",Information);  

