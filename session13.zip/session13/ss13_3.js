let size = +prompt("Nhập vào số sinh viên cần quản lí");
let students = [];
for (let i = 0; i < size; i++) {
  let student = new Object();
  student.id = prompt("Nhập mã sinh viên: "+(i+1)+":");
  student.name = prompt("Nhập tên sinh viên:"+(i+1)+":");
  students.push(student);    
}
console.log("Tất cả sinh viên cần quản lí là:",students)