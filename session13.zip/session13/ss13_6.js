let store = [
    {id:1,name:"iphone12",price:2000},
    {id:2,name:"iphone11",price:1000},
    {id:3,name:"samsung note 10",price:5000}
]
    store.sort((a,b)=>a.price-b.price);
console.log("Output",store)

 

