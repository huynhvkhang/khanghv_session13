let Product = {
    id: "vn001",
    name: "Huỳnh Vĩ Khang",
    price: "0809416xxxx",
    quantity: "jav",
}
console.log("product và giá trị là:", Product.id)
console.log("product và giá trị là:", Product.name)
console.log("product và giá trị là:", Product.price)
console.log("product và giá trị là:", Product.quantity)