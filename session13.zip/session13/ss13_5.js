let store = [
    {
        author: "Fujiko Fujio",
        name: "Doraemom",
    },
    {
        author: "Tajiri Satoshi Sugimori",
        name: "Pokemon",
    },
    {
        author: "Nguyễn Du",
        name: "Truyện kiều",
    },

];
let search = prompt("Nhập tên tác giả: ");
let exit = true;
for (let i = 0; i < store.length; i++) {
    if (store[i].author.includes(search)) {
        exit = false;
        console.log(store[i])
    }
}
if (exit == true) {
    console.log("không tồn tại quyển sách có tác giả tên là " + search);
}