let Information=new Object()
Information.id = prompt("Hãy nhập id của bạn: ");
Information.name = prompt("Hãy nhập name của bạn: ");
Information.phone = prompt("Hãy nhập phone của bạn: ");
Information.address = prompt("Hãy nhập address của bạn: ");
Information.info = function (){
    return " Hãy nhập vào đây " +this.Information
}
console.log("Thông tin của bạn là: ",Information);